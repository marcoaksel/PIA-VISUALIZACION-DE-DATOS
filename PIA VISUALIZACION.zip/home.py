import sys
from PyQt5 import QtWidgets,QtCore
from ui_comentarios import Ui_Form
from ui_home import Ui_MainWindow
import matplotlib.pyplot as plt
import seaborn as sns
import mysql.connector

#nombre de la base de datos por consultar, crear o modificar
db ="figuras_n"
#funcion para que se cree una base de datos en caso de que no haya una aun
def crear_base_datos(db):
    try:
        conexion = mysql.connector.connect(host="localhost",
                                        user="root",
                                        password="Pa$$w0rd")
        cursor = definir_cursor(conexion)
        cursor.execute(f"CREATE DATABASE {db};")
        cursor.execute(f"USE {db};")
        cursor.execute("""
                CREATE TABLE configuraciones(
                            id int primary key NOT NULL AUTO_INCREMENT,
                            titulo varchar(70) DEFAULT NULL,
                            x varchar(30) DEFAULT NULL,
                            valores_x text,
                            y varchar(30) DEFAULT NULL,
                            valores_y text,
                            grafica varchar(15) DEFAULT NULL,
                            libreria varchar(15) DEFAULT NULL,
                            comentarios text DEFAULT NULL


                );


            """)
        conexion.close()

    except:
        lanzarMensaje("Informacion","Ha ocurrido una excepcion con la base de datos. Puede que no haya creado. Si no puede consultar,guardar figura, verifique parametros de conexión.\n"
                                    "Si todo corre bien omita este mensaje.")





#funcion para conectarnos a la base de datos donde se almacena la configuracion de la grafica
def conectar(db):
    try:
        conexion = mysql.connector.connect(host="localhost",
                                        user="root",
                                        password="Pa$$w0rd",
                                        database=db)
    except:
        mensaje = "Error al intentar conectarse con la base de datos. Favor de verificar los parametros de conexion con la base de datos."
        lanzarMensaje("ERROR", mensaje)
    else:
        return conexion
#funcion para definir un cursor el cual servira como enlaze con la base de datos
def definir_cursor(conexion):
    try:
        mycursor = conexion.cursor()

    except:
        mensaje = "Error al intentar definir el cursor. Favor de verificar los parametros de conexion con la base de datos."
        lanzarMensaje("ERROR", mensaje)
    else:
        return mycursor

#funcion para instertar un registro nuevo
def insertar(conexion,cursor,titulo,x,valores_x,y,valores_y,tipo,libreria,comentarios):
    try:
        _valores_x = ""
        _valores_y = ""
        for i in valores_x:
            _valores_x += str(i)
            _valores_x += ","
        for i in valores_y:
            _valores_y += str(i)
            _valores_y += ","
        codigo_sql = "INSERT INTO configuraciones (titulo,x,valores_x,y,valores_y,grafica,libreria,comentarios) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
        valores = (titulo, x, _valores_x, y, _valores_y, tipo, libreria, comentarios)
        cursor.execute(codigo_sql, valores)
        conexion.commit()
    except:
        lanzarMensaje("Error","Error al insertar.")
    else:
        lanzarMensaje("DONE","Exitoso.")

    
#funcion para consultar las configuraciones las cuales se van a almacenar en la tablewidget correspondiente
def consultar(cursor):
    sql = "SELECT titulo,grafica,libreria,x,valores_x,y,valores_y,comentarios FROM configuraciones"
    try:
        cursor.execute(sql)
        conf = cursor.fetchall()
    except:
        mensaje = "Error al consultar los registros, asegurese de tener bien configurada la base de datos."
        lanzarMensaje("ERROR", mensaje)
    else:
        return conf
#funcion para desconectar el servidor
def desconectar(conexion):
    try:
        conexion.close()
    except:
        mensaje="Error al desconectarse. Verifique Parametros de conexión."
        lanzarMensaje("Error",mensaje)
#funcion para ver si hay espacio en el texto ingresado
def espacios(word):
    return word.replace(" ","")
#funcion para validar que sean numeros y no otros caracteres
def validar_numero(n):
    try:
        n=float(n)
    except:
        return False
    else:
        return True
#funcion para mostrar mensaje en pantalla
def lanzarMensaje(titulo, texto):
    #definimos boton
    box = QtWidgets.QMessageBox()
    box.setIcon(QtWidgets.QMessageBox.Information)
    box.setWindowTitle(titulo)
    box.setText(texto)
    #lo ejecutamos
    box.exec_()
#funcion para preguntar algo al usuario
def question(titulo, text):
    box = QtWidgets.QMessageBox()
    box.setIcon(QtWidgets.QMessageBox.Information)
    box.setText(text)
    box.setWindowTitle(titulo)
    box.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
    #DEFINIMOS VARIABLES PARA QUE GUARDE LA RESPUESTA
    respuesta = box.exec_()
    #retornamos el valor
    return respuesta
#Clase principal
class Home(QtWidgets.QMainWindow):
    #Constructor de la ventana principal
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.rellenarTabla(6,self.ui.table_datos)
        self.rellenar_guardas()
        self.ui.btn_generar_grafica.clicked.connect(lambda : self.generar(self.ui.table_datos))
        self.ui.btn_agregar_campo.clicked.connect(lambda :self.agregar_campo(self.ui.table_datos))
        self.ui.btn_grafica_tabla.clicked.connect(self.vaciar)
    #metodo para limpiar la tabla y evitar que se rellene duplicadamente
    def limpiar_tabla(self,tabla):
        for i in reversed(range(tabla.rowCount())):
            #borramos la fila con indice del iterador
            tabla.removeRow(i)
    #metodo para rellenar la tabla de 6 celdas sin ningun valor
    def rellenarTabla(self,n,tabla):
        self.limpiar_tabla(tabla)
        for i in range(n):
            # obtenemos la cantidad de filas
            rowPosition = tabla.rowCount()
            # insertamos fila
            tabla.insertRow(rowPosition)
            #numero de columnas
            numCols = tabla.columnCount()
            #numero de filas
            numRows = tabla.rowCount()
            # definimos el numero de filas
            tabla.setRowCount(numRows)
            # definimos el numero de columnas
            tabla.setColumnCount(numCols)
            for y in range(2):
                tabla.setItem(numRows - 1, y, QtWidgets.QTableWidgetItem())
    #metodo para agregar un campo mas en caso de que sea necesario
    def agregar_campo(self,tabla):
        rowPosition = tabla.rowCount()
        # insertamos una fila en la posicion que nos daba la variable anterior
        tabla.insertRow(rowPosition)
        #numero de columnas
        numCols = tabla.columnCount()
        #numero de filas
        numRows = tabla.rowCount()
        # definimos el numero de filas
        tabla.setRowCount(numRows)
        # definimos el numero de columnas
        tabla.setColumnCount(numCols)
        for y in range(2):
            tabla.setItem(numRows - 1, y, QtWidgets.QTableWidgetItem())
    #metodo para generar la grafica que a la vez valida la informacion ingresada por el usuario
    def generar(self,tabla):

        valores = []
        configuracion = []
        x = list()
        y = list()

        tipo = ""
        libreria = ""
        seguir = False
        titulo = ""
        etiquetax=""
        etiquetay=""

        for i in self.ui.grupo_tipo.buttons():

            if i.isChecked():
                tipo = i.text()
                break
        for i in self.ui.grupo_libreria.buttons():
            if i.isChecked():
                libreria = i.text()

                break

        if libreria!="" and tipo !="":
            seguir = True
        elif libreria == "":
            lanzarMensaje("Error", "No se ha elegido el tipo de tabla.")
        elif tipo == "":
            lanzarMensaje("Error", "No se ha elegido la libreria.")

        if seguir:
            n = tabla.rowCount()

            if len(self.ui.titulo.text().replace(" ", "")) > 0:
                titulo=self.ui.titulo.text()
            else:
                seguir = False
                lanzarMensaje("Error", "Titulo no capturado")
        else:
            lanzarMensaje("Error", "Escoja libreria.")
        if seguir:
            if tipo != "DE PASTEL":

                if len(self.ui.titulox.text().replace(" ", "")) > 0:
                    etiquetax=self.ui.titulox.text()
                else:
                    seguir = False
                    lanzarMensaje("Error", "Titulo X no capturado.")
                if len(self.ui.tituloy.text().replace(" ", "")) > 0:
                    etiquetay=self.ui.tituloy.text()
                else:
                    seguir= False
                    lanzarMensaje("Error", "Titulo X no capturado.")
            else:
                etiquetax = "N/A"
                etiquetay = "N/A"

        if seguir:
            campos_sin_rellenar = 0
            campos_ocupados = 0
            for i in range(n):
                celda_x = tabla.item(i, 0).text()
                celda_y = tabla.item(i, 1).text()
                _celda_x = espacios(celda_x)

                if (len(espacios(celda_x)) > 0) and (validar_numero(celda_y)==True):

                    if campos_sin_rellenar == 1:
                        lanzarMensaje("Error", "Hay Lugares sin llenar en la tabla de datos.")
                        seguir= False
                        x = []
                        y = []
                        break
                    else:
                        x.append(celda_x)
                        y.append(float(celda_y))
                        campos_ocupados = campos_ocupados + 1
                elif (len(espacios(celda_x)) == 0 and (validar_numero(celda_y))):
                    lanzarMensaje("Error", f"Valor de la columna X de la fila {i + 1} no capturado")
                    seguir = False
                    break
                elif (len(espacios(celda_x)) > 0 and (validar_numero(celda_y))==False):
                    lanzarMensaje("Error", f"Valor de la columna Y de la fila {i + 1} no valido")
                    seguir = False
                    break
                elif (len(espacios(celda_x)) > 0 and len(espacios(celda_y)) == 0):
                    lanzarMensaje("Error", f"Valor de la columna Y de la fila {i + 1} no ingresado")
                    seguir = False
                    break
                elif len(espacios(celda_x)) == 0 and len(espacios(celda_y)) == 0:
                    campos_sin_rellenar =+ 1
                elif len(espacios(celda_x)) == 0:
                    lanzarMensaje("Error", f"Valor de la columna X de la fila {i + 1} no capturado")
                    seguir = False
                    break

            tabla_completa = False
            if campos_ocupados >= 1:
                valores.append(x)
                valores.append(y)
                tabla_completa = True
            elif campos_ocupados < 1:
                lanzarMensaje("Error", "Debe ingresar mas de un valor.")
                seguir = False
        print(seguir)
        # si todo sale bien y los valores son correctos prosigue a generar la grafica en base a los datos ingresados
        if seguir and tabla_completa:
            configuracion.append(titulo)
            configuracion.append(etiquetax)
            configuracion.append(etiquetay)
            configuracion.append(valores)
            configuracion.append(tipo)
            configuracion.append(libreria)

            dict_conf = {
                "Titulo gráfica": configuracion[0],
                "Titulo X": configuracion[1],
                "Valores X": configuracion[3][0],
                "Titulo Y": configuracion[2],
                "Valores Y": configuracion[3][1],
                "Tipo de gráfica": configuracion[4],
                "Librería": configuracion[5]

            }

            _titulo = dict_conf['Titulo gráfica']
            _titulox = dict_conf['Titulo X']
            _tituloy = dict_conf['Titulo Y']
            _valores_x = dict_conf['Valores X']
            _valores_y = dict_conf['Valores Y']
            _tipo = dict_conf["Tipo de gráfica"]
            _libreria = dict_conf["Librería"]

            if len(_valores_x) > 1:

                generar = question("ATENCION", "¿DESEA GENERAR LA GRÁFICA CON LA CONFIGURACIÓN ELEGIDA?")

                if generar == 1024:

                    try:
                        plt.close()
                        self.guardar.close()
                    except:
                        pass
                    # dependiendo la libreria se genera la grafica

                    # matplotlib
                    if _libreria == "MATPLOTLIB":
                        print("Matplot")
                        if _tipo == "DE BARRA":
                            plt.title(_titulo)
                            plt.xlabel(_titulox)
                            plt.ylabel(_tituloy)
                            plt.bar(_valores_x,_valores_y)
                            plt.show()


                        elif _tipo == "DE LÍNEAS":
                            plt.title(_titulo)
                            plt.xlabel(_titulox)
                            plt.ylabel(_tituloy)
                            plt.plot(_valores_x, _valores_y,"-o")
                            plt.show()

                        elif _tipo == "DE PASTEL":
                            plt.pie(_valores_y,
                                    labels=_valores_y, autopct='%1.1f%%')
                            plt.title(_titulo)
                            plt.show()
                        self.comentar(_titulo,_titulox,_tituloy,_valores_x,_valores_y,tipo,libreria)


                    # seaborn
                    elif configuracion[-1] == "SEABORN":
                        datos_grafica = {_titulox: _valores_x,
                                         _tituloy: _valores_y}
                        sns.set_theme(style="darkgrid")
                        if _tipo.upper() == "DE BARRA":
                            sns.barplot(x=_titulox,
                                        y=_tituloy, data=datos_grafica)

                            plt.title(_titulo)
                            plt.show()

                        if _tipo == "DE LÍNEAS":
                            sns.lineplot(x=_titulox,
                                         y=_tituloy, data=datos_grafica, marker="o")
                            plt.title(_titulo)
                            plt.show()
                        if _tipo == "DE PASTEL":
                            plt.pie(_valores_y,
                                    labels=_valores_x, autopct='%1.1f%%')
                            plt.title(_titulo)
                            plt.show()
                        self.comentar(_titulo,_titulox,_tituloy,_valores_x,_valores_y,tipo,libreria)

            elif len(_valores_x)==1 or len(_valores_x)==0:
                lanzarMensaje("Error", "No es posible generar una grafica de un solo valor")

#metodo que devuelve la pantalla para comentar y guardar
    def comentar(self,titulo,titulo_x,titulo_y,valores_x,valores_y,tipo,libreria):
        self.ventana_guardar = QtWidgets.QMainWindow()
        self.ui_guardar = Ui_Form()
        self.ui_guardar.setupUi(self.ventana_guardar)
        


        titulo = titulo
        titulo_x = titulo_x
        valores_x = valores_x
        valores_y = valores_y
        tipo = tipo
        libreria = libreria
        self.ui_guardar.btn_guardar.clicked.connect(lambda : self.guardar(titulo,titulo_x,titulo_y,valores_x,valores_y,tipo,libreria))
        
        self.ventana_guardar.show()
#metodo apra guardar la informacion ingresada por el usuario
    def guardar(self, titulo, titulo_x, titulo_y, x, y, tipo,libreria):
        comentarios = self.ui_guardar.ipt_guardar.toPlainText()

        seguir_sin_comentarios =0
        if len(comentarios)<0:
            seguir_sin_comentarios = question("Info","No hay comentarios ingresados, ¿Desea seguir?")
        else:
            save = True
        if seguir_sin_comentarios == 1024 or save:
            guardar_grafica = question("Info", "¿Desea guardar la gráfica?")
            if guardar_grafica == 1024:
                titulo = titulo
                titulo_x = titulo_x
                titulo_y = titulo_y
                x = x
                y = y
                tipo = tipo
                libreria = libreria
                comentarios = comentarios
                conexion = conectar(db)
                cursor = definir_cursor(conexion)
                insertar(conexion, cursor, titulo, titulo_x, x, titulo_y, y, tipo, libreria, comentarios)
                desconectar(conexion)
                self.rellenar_guardas()
                self.clean()
                try:
                    plt.close()
                except:
                    pass
                self.ventana_guardar.close()
                
#metodo para limpiar los campos y la tabla de datos
    def clean(self):
        self.rellenarTabla(6,self.ui.table_datos)
        self.ui.titulo.setText("")
        self.ui.tituloy.setText("")
        self.ui.titulox.setText("")
    #metodo para rellenar la tabla de configuraciones guardadas
    def rellenar_guardas(self):
        self.limpiar_tabla(self.ui.table_guardadas)
        conexion = conectar(db)
        cursor = definir_cursor(conexion)
        guardadas = consultar(cursor)
        desconectar(conexion)

        for i in guardadas:
            print(i)
        for i in guardadas:
            # guardamos la cantidad de filas
            rowPosition = self.ui.table_guardadas.rowCount()
            # insertamos una fila en base a la cantidad de filas que hay
            self.ui.table_guardadas.insertRow(rowPosition)
            #numero de columnas
            numCols = self.ui.table_guardadas.columnCount()
            #numero de filas
            numRows = self.ui.table_guardadas.rowCount()
            # definimos el numero de filas
            self.ui.table_guardadas.setRowCount(numRows)
            # definimos el numero de columnas
            self.ui.table_guardadas.setColumnCount(numCols)
            # se define variable de caracter contador
            c = 0
            # recorremos cada valor del elemento actual
            for y in i:
                # si c es igual a esto se convierte a combobox para una mejor visualizacion de datos
                if c == 4 or c == 6:

                    cb = QtWidgets.QComboBox()


                    x = ""
                    for z in y:
                        if z==",":
                            cb.addItem(x)
                            x = ""
                        else:

                            x = x + z

                    self.ui.table_guardadas.setCellWidget(numRows - 1, c, cb)

                    c = c + 1
                else:
                    print(c)
                    self.ui.table_guardadas.setItem(numRows - 1, c, QtWidgets.QTableWidgetItem(str(y)))
            #la hacemos no editable
                    flags = QtCore.Qt.ItemIsSelectable
                    self.ui.table_guardadas.item(numRows - 1, c).setFlags(flags)
                    c = c + 1
    #metodo para rellenar los campos en base a una configuracion guardada
    def vaciar(self):
        valores = []
        valores_x = []
        valores_y = []
        numRows = self.ui.table_guardadas.rowCount()

        if numRows > 0:

            fila = (self.ui.table_guardadas.currentRow())
            for i in range(8):

                if i == 4:

                    cb = self.ui.table_guardadas.cellWidget(fila, i)
                    for y in range(len(cb)):
                        valores_x.append(cb.itemText(y))
                    valores.append(valores_x)
                elif i == 6:
                    cb = self.ui.table_guardadas.cellWidget(fila, i)
                    for y in range(len(cb)):
                        valores_y.append(cb.itemText(y))
                    valores.append(valores_y)
                elif i != 4 and i != 6:

                    valores.append(self.ui.table_guardadas.item(fila, i).text())

            print(valores)

            for i in self.ui.grupo_tipo.buttons():
                if i.text() == valores[1]:
                    i.setChecked(True)

            for i in self.ui.grupo_libreria.buttons():
                if i.text() == valores[2]:
                    i.setChecked(True)
            self.ui.titulo.setText(valores[0])
            self.ui.titulox.setText(valores[3])
            self.ui.tituloy.setText(valores[5])

            n = len(valores[4])
            self.rellenarTabla(n,self.ui.table_datos)
            for i in range(n):
                self.ui.table_datos.setItem(i, 0, QtWidgets.QTableWidgetItem(str(valores[4][i])))
                self.ui.table_datos.setItem(i, 1, QtWidgets.QTableWidgetItem(str(valores[6][i])))



            

#condicional para ejecutar la aplicacion
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    crear_base_datos(db)
    ventana = Home()
    ventana.show()
    app.setStyle("Windows")
    sys.exit(app.exec_())